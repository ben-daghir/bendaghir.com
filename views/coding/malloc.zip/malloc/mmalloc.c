/*
 * CS 2110 Spring 2018
 * Author: Name here
 */

/* we need this for uintptr_t */
#include <stdint.h>
/* we need this for memcpy/memset */
#include <string.h>
/* we need this to print out stuff*/
#include <stdio.h>
/* we need this for msbrk */
#include "msbrk.h"
/* we need this for the metadata_t struct and my_malloc_err enum definitions */
#include "mmalloc.h"

/* Our freelist structure - our freelist is represented as two doubly linked lists
 * the address_list orders the free blocks in ascending address
 * the size_list orders the free blocks by size
 */

metadata_t *address_list;
metadata_t *size_list;

/* Set on every invocation of my_malloc()/my_free()/my_realloc()/
 * my_calloc() to indicate success or the type of failure. See
 * the definition of the my_malloc_err enum in my_malloc.h for details.
 * Similar to errno(3).
 */
enum my_malloc_err my_malloc_errno;

/* Static method to remove item from address_list
 *
 *@param block_ptr Pointer to the block we are removing from list
 *@return void
 */
static void remove_address_list(metadata_t* block_ptr) {
	if (address_list->prev_addr == NULL && address_list->next_addr == NULL) {
		address_list = NULL;
		return;
	}
	if (block_ptr->prev_addr != NULL)
	block_ptr->prev_addr->next_addr = block_ptr->next_addr;
	if (block_ptr->next_addr != NULL) {
		block_ptr->next_addr->prev_addr = block_ptr->prev_addr;
		if (block_ptr->prev_addr == NULL) address_list = block_ptr->next_addr;
	}
}

/* Static method to add item from address_list
 *
 *@param block_ptr Pointer to the block we are adding to list
 *@return void
 */
static void add_address_list(metadata_t* block_ptr) {
	//Condition for empty list
	if (address_list == NULL) {
		address_list = block_ptr;
		return;
	}

	//Condition for adding between [0, end)
	metadata_t* current_node = address_list;
	while (current_node != NULL) {
		if (block_ptr < current_node) {
			block_ptr->next_addr = current_node;
			block_ptr->prev_addr = current_node->prev_addr;
			if (block_ptr->prev_addr != NULL)
				block_ptr->prev_addr->next_addr = block_ptr;
			if (block_ptr->next_addr != NULL)
				block_ptr->next_addr->prev_addr = block_ptr;
			if (block_ptr->prev_addr == NULL) address_list = block_ptr;
			return;
		}
		current_node = current_node->next_addr;
	}

	//Condition for adding at the very end
	current_node = address_list;
	while (current_node->next_addr != NULL) current_node = current_node->next_addr;
	block_ptr->next_addr = NULL;
	block_ptr->prev_addr = current_node;
	block_ptr->prev_addr->next_addr = block_ptr;
	return;
}

/* Static method to remove item from size_list
 *
 *@param block_ptr Pointer to the block we are removing from list
 *@return void
 */
static void remove_size_list(metadata_t* block_ptr) {
	if (block_ptr->prev_size == NULL && block_ptr->next_size == NULL) {
		size_list = NULL;
		return;
	}
	if (block_ptr->prev_size != NULL)
	block_ptr->prev_size->next_size = block_ptr->next_size;
	if (block_ptr->next_size != NULL) {
		block_ptr->next_size->prev_size = block_ptr->prev_size;
		if (block_ptr->prev_size == NULL) size_list = block_ptr->next_size;
	}
}

/* Static method to add item from size_list
 *
 *@param block_ptr Pointer to the block we are adding to list
 *@return void
 */
static void add_size_list(metadata_t* block_ptr) {
	// metadata_t* n = size_list;
	// //printf("Before = %lu\n", block_ptr->size);
	// while (n != NULL) {
	// 	//printf("%lu\n", n->size);
	// 	n = n->next_size;
	// }
	//Condition for empty list
	if (size_list == NULL) {
		size_list = block_ptr;
		return;
	}

	//Condition for adding between [0, end)
	metadata_t* current_node = size_list;
	while (current_node != NULL) {
		if (block_ptr->size < current_node->size) {
			block_ptr->next_size = current_node;
			block_ptr->prev_size = current_node->prev_size;
			if (block_ptr->prev_size != NULL)
				block_ptr->prev_size->next_size = block_ptr;
			if (block_ptr->next_size != NULL)
				block_ptr->next_size->prev_size = block_ptr;
			if (block_ptr->prev_size == NULL) size_list = block_ptr;
			return;
		}
		current_node = current_node->next_size;
	}

	//Condition for adding at the very end
	current_node = size_list;
	while (current_node->next_size != NULL) current_node = current_node->next_size;
	block_ptr->next_size = NULL;
	block_ptr->prev_size = current_node;
	block_ptr->prev_size->next_size = block_ptr;
	return;
}

/* Static method to help split a big enough memory
 *
 * @param block_ptr - pointer to the block of data you want to split
 * @param total     - the total size of the memory being allocated
 * @return a pointer to the split memory availible for the user
 */
static metadata_t* split_helper(metadata_t* block_ptr, size_t total) {
	remove_address_list(block_ptr);
	remove_size_list(block_ptr);
	metadata_t* user_block_ptr = (metadata_t*)(((uint8_t*)block_ptr) + block_ptr->size - total);
	metadata_t free_data = {block_ptr->prev_addr, block_ptr->next_addr,
							block_ptr->prev_size, block_ptr->next_size,
							(block_ptr->size - total), 0};
	*block_ptr = free_data;
	if (size_list == NULL && address_list == NULL) {
		size_list = block_ptr;
		address_list = block_ptr;
		return user_block_ptr;
	}
	add_address_list(block_ptr);
	add_size_list(block_ptr);
	return user_block_ptr;
}

/* Static method to help merge memory when possible
 * @param -
 * @return none
 */
static int merge_mem() {
	metadata_t* node = address_list;
	if (node == NULL) return 0;
	while (node->next_addr != NULL) {
		if ((((uint8_t*)node) + (node->size)) == (uint8_t*)node->next_addr) {

			metadata_t* a_node = node;
			metadata_t* b_node = node->next_addr;
			metadata_t merged_data = {NULL, NULL, NULL, NULL,
											(a_node->size + b_node->size), 0};
			remove_address_list(a_node);
			remove_size_list(a_node);
			remove_address_list(b_node);
			remove_size_list(b_node);
			*b_node = merged_data;
			*a_node = merged_data;
			add_address_list(a_node);
			add_size_list(a_node);
			return 1;
		}
		node = node->next_addr;
	}
	return 0;
}

/* MALLOC
 * See my_malloc.h for documentation
 */
void* my_malloc(size_t size) {
	//Handle all errors and initialize
	if (size == 0) {
		my_malloc_errno = NO_ERROR;
		return NULL;
	}
	unsigned long canary = 0;
	size_t total = size + TOTAL_METADATA_SIZE;
	//printf("size%lu total:%lu\n", size, total);
	if (total > SBRK_SIZE) {
		my_malloc_errno = SINGLE_REQUEST_TOO_LARGE;
		return NULL;
	}

	//Iterate through the lists
	metadata_t* current_node = size_list;
	while (current_node != NULL) {
		if (current_node->size == total) {
			remove_address_list(current_node);
			remove_size_list(current_node);
			canary = ((uintptr_t)current_node ^ CANARY_MAGIC_NUMBER) + 1;
			metadata_t metadata = {NULL, NULL, NULL, NULL, total, canary};
			*current_node = metadata;
			*((unsigned long*)(((uint8_t*)current_node) + total - sizeof(unsigned long))) = canary;
			my_malloc_errno = NO_ERROR;
			while(merge_mem());
			return (current_node + 1);
		} else if (current_node->size >= (total + MIN_BLOCK_SIZE)) {
			current_node = split_helper(current_node, total);
			canary = ((uintptr_t)current_node ^ CANARY_MAGIC_NUMBER) + 1;
			metadata_t metadata = {NULL, NULL, NULL, NULL, total, canary};
			*current_node = metadata;
			*((unsigned long*)(((uint8_t*)current_node) + total - sizeof(unsigned long))) = canary;
			my_malloc_errno = NO_ERROR;
			while(merge_mem());
			return (current_node + 1);
		}
		current_node = current_node->next_size;
	}

	//Calling msbrk
	metadata_t* block_ptr = msbrk(SBRK_SIZE);
	if (block_ptr == NULL) {
		my_malloc_errno = OUT_OF_MEMORY;
		return NULL;
	}
	metadata_t freedata = {NULL, NULL, NULL, NULL, SBRK_SIZE, 0};
	*block_ptr = freedata;
	add_size_list(block_ptr);
	add_address_list(block_ptr);
	block_ptr = split_helper(block_ptr, total);
	canary = ((uintptr_t)block_ptr ^ CANARY_MAGIC_NUMBER) + 1;
	metadata_t metadata = {NULL, NULL, NULL, NULL, total, canary};
	*block_ptr = metadata;
	*((unsigned long*)(((uint8_t*)block_ptr) + total - sizeof(unsigned long))) = canary;
	my_malloc_errno = NO_ERROR;
	while(merge_mem());
	return (block_ptr + 1);
}

/* REALLOC
 * See my_malloc.h for documentation
 */
void *my_realloc(void *ptr, size_t size) {

	if (ptr == NULL && size != 0) {
		void* new_ptr = my_malloc(size);
		if (new_ptr == NULL) return NULL;
		return new_ptr;
	} else if (size == 0 && ptr != NULL) {
		my_free(ptr);
		my_malloc_errno = NO_ERROR;
		return NULL;
	} else if (size == 0 && ptr == NULL) {
		my_malloc_errno = NO_ERROR;
		return NULL;
	}

	metadata_t* block_ptr = (metadata_t*)(((uint8_t*) ptr) - sizeof(metadata_t));
	unsigned long real_canary = ((uintptr_t)block_ptr ^ CANARY_MAGIC_NUMBER) + 1;
	if (block_ptr->canary != real_canary) {
		my_malloc_errno = CANARY_CORRUPTED;
		return NULL;
	}
	unsigned long* end_canary = (unsigned long*)
								(((uint8_t*)(block_ptr)) + block_ptr->size
								- sizeof(unsigned long));
	if (*end_canary != real_canary) {
		my_malloc_errno = CANARY_CORRUPTED;
		return NULL;
	}

	void* new_ptr = my_malloc(size);
	if (new_ptr == NULL) return NULL;
	if ((block_ptr->size - TOTAL_METADATA_SIZE) > size) {
		memcpy(new_ptr, ptr, size);
	} else {
		memcpy(new_ptr, ptr, block_ptr->size);
	}

	my_free(ptr);
	my_malloc_errno = NO_ERROR;
    return new_ptr;
}

/* CALLOC
 * See my_malloc.h for documentation
 */
void *my_calloc(size_t nmemb, size_t size) {
	if (nmemb == 0 || size == 0) {
		my_malloc_errno = NO_ERROR;
		return NULL;
	}
	void* ptr = my_malloc(nmemb * size);
	if (ptr == NULL) return NULL;
	for (size_t i = 0; i < (nmemb * size); i++) {
		*((uint8_t*)ptr + i) = 0;
	}
	my_malloc_errno = NO_ERROR;
    return ptr;
}

/* FREE
 * See my_malloc.h for documentation
 */
void my_free(void *ptr) {
	if (ptr == NULL) {
		my_malloc_errno = NO_ERROR;
		return;
	}
	metadata_t* block_ptr = (metadata_t*)(((uint8_t*) ptr) - sizeof(metadata_t));
	unsigned long real_canary = ((uintptr_t)block_ptr ^ CANARY_MAGIC_NUMBER) + 1;
	if (block_ptr->canary != real_canary) {
		my_malloc_errno = CANARY_CORRUPTED;
		return;
	}
	unsigned long* end_canary = (unsigned long*)
								(((uint8_t*)(block_ptr)) + block_ptr->size
								- sizeof(unsigned long));
	if (*end_canary != real_canary) {
		my_malloc_errno = CANARY_CORRUPTED;
		return;
	}

	add_address_list(block_ptr);
	add_size_list(block_ptr);
	while(merge_mem());
	my_malloc_errno = NO_ERROR;
	return;

}
